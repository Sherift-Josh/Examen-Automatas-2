import csv
import statistics

RUTAS = ("./sexenio-1.csv", "./sexenio-2.csv")

for ruta in RUTAS:
    with open(ruta, newline="", encoding="utf-8") as archivo:
        lector = csv.reader(archivo)
        next(lector)
        datos = [float(fila[1]) for fila in lector if fila[1] != "N/E"]

    print(f"\n{ruta}")
    print(f"Media: {statistics.mean(datos):.4f}")
    print(f"Varianza: {statistics.pvariance(datos):.4f}")
    print(f"Desviación estándar: {statistics.pstdev(datos):.4f}")
    print(f"Máximo: {max(datos):.4f}")
    print(f"Mínimo: {min(datos):.4f}")
    print(f"Rango: {max(datos) - min(datos):.4f}")
