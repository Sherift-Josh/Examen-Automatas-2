precio <- c(64000, 59000, 61500, 79000, 87500, 92500, 95000, 113000, 115000, 138000, 142500, 144000, 145000, 147500, 144000, 155500, 165000)
pies <- c(1670, 1339, 1712, 1840, 2300, 2234, 2311, 2377, 2736, 2500, 2500, 2479, 2400, 3124, 2500, 4062, 2854)
dormitorios <- c(2, 2, 3, 3, 3, 3, 3, 3, 4, 3, 4, 3, 3, 4, 3, 4, 3)
antiguedad <- c(30, 25, 30, 40, 18, 30, 19, 7, 10, 1, 3, 3, 1, 0, 2, 10, 3)

datos <- data.frame(precio, pies, dormitorios, antiguedad)

modelo_ex4 <- lm(precio ~ pies + dormitorios, data = datos)
summary(modelo_ex4)

nueva_casa_ex4 <- data.frame(pies = 2000, dormitorios = 3)

prediccion_ex4 <- predict(modelo_ex4, newdata = nueva_casa_ex4)
print(prediccion_ex4)
