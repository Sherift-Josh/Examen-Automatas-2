s = int(input("Ingresa el precio por unidad: "))
f = int(input("Ingresa el costo fijo: "))
v = int(input("Ingresa el costo variable por unidad: "))

pequilibrio = f/(s-v)
print("El punto de equilibrio es: ", pequilibrio)